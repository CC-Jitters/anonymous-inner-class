public class A {

    public void show() {

        System.out.println("In A Show!");

    }

}
